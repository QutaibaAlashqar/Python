
year = int(input("Yil: "))

if year % 12 == 8:
	animal = "Ejderha"

elif year % 12 == 9:
	animal = "Yilan"

elif year % 12 == 10:
	animal = "At"

elif year % 12 == 11:
	animal = "Koyun"

elif year % 12 == 0:
	animal = "Maymun"

elif year % 12 == 1:
	animal = "Horoz"

elif year % 12 == 2:
	animal = "Kopek"

elif year % 12 == 3:
	animal = "Domuz"

elif year % 12 == 4:
	animal = "Fare"

elif year % 12 == 5:
	animal = "Okuz"

elif year % 12 == 6:
	animal = "Kaplan"

elif year % 12 == 7:
	animal = "Tavsan"

print(str(year) + " : " + animal)
