side1 = float(input("Kenar1: "))
side2 = float(input("Kenar2: "))
side3 = float(input("Kenar3: "))

if side1 == side2 and side2 == side3:
	name = "eskenar"

elif side1 == side2 or side2 == side3 or side1 == side3:
	name = "ikizkenar"

else:
	name = "cesitkenar"

print(name + " ucgen")
