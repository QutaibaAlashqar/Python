n = int(input())

sum=0


for i in range(n):
	sayi = int(input())
	sum += sayi

print(sum)

