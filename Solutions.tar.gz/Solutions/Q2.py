n = int(input())

min = int(input())

for i in range(n):

	sayi = int(input())

	if min > sayi:
		min = sayi

print(min)
